from django.contrib import admin
from .models import Menus, Platos, Ventas

admin.site.register(Menu)
admin.site.register(Plato)
admin.site.register(Descripcion)
# Register your models here.
